// Canvas setup
const canvas = document.getElementById("pongCanvas");
const ctx = canvas.getContext("2d");

// Paddle dimensions
const paddleWidth = 10;
const paddleHeight = 100;

// Ball dimensions
const ballRadius = 10;

// Game objects
const player = {
    x: 0,
    y: canvas.height / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    color: "white",
    score: 0
};

const ai = {
    x: canvas.width - paddleWidth,
    y: canvas.height / 2 - paddleHeight / 2,
    width: paddleWidth,
    height: paddleHeight,
    color: "white",
    score: 0
};

const ball = {
    x: canvas.width / 2,
    y: canvas.height / 2,
    radius: ballRadius,
    speed: 5,
    velocityX: 5,
    velocityY: 5,
    color: "white"
};

// Event listener for player control
canvas.addEventListener("mousemove", movePaddle);

function movePaddle(event) {
    const rect = canvas.getBoundingClientRect();
    player.y = event.clientY - rect.top - player.height / 2;
}

// Render the game objects
function drawRect(x, y, width, height, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
}

// Draw the ball
function drawBall(x, y, radius, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2, false);
    ctx.closePath();
    ctx.fill();
}

// Draw the net
function drawNet() {
    for (let i = 0; i <= canvas.height; i += 15) {
        drawRect(canvas.width / 2 - 1, i, 2, 10, "white");
    }
}

// Draw text
function drawText(text, x, y) {
    ctx.fillStyle = "white";
    ctx.font = "40px Arial";
    ctx.fillText(text, x, y);
}

// Reset the ball position
function resetBall() {
    ball.x = canvas.width / 2;
    ball.y = canvas.height / 2;
    ball.velocityX = -ball.velocityX;
    ball.speed = 5;
}

// Detect collision
function collision(b, p) {
    return (
        b.x - b.radius < p.x + p.width &&
        b.x + b.radius > p.x &&
        b.y - b.radius < p.y + p.height &&
        b.y + b.radius > p.y
    );
}

// Update game objects
function update() {
    // Update ball position
    ball.x += ball.velocityX;
    ball.y += ball.velocityY;

    // Simple AI movement
    ai.y += (ball.y - (ai.y + ai.height / 2)) * 0.1;

    // Ball collision with top and bottom walls
    if (ball.y - ball.radius < 0 || ball.y + ball.radius > canvas.height) {
        ball.velocityY = -ball.velocityY;
    }

    // Determine which paddle the ball is hitting
    const paddle = ball.x < canvas.width / 2 ? player : ai;

    // Ball collision with paddles
    if (collision(ball, paddle)) {
        // Normalize ball position relative to the paddle center
        let collidePoint = (ball.y - (paddle.y + paddle.height / 2)) / (paddle.height / 2);

        // Calculate angle in radians
        let angleRad = collidePoint * Math.PI / 4;

        // Direction of the ball based on which paddle it hit
        let direction = (ball.x < canvas.width / 2) ? 1 : -1;
        ball.velocityX = direction * ball.speed * Math.cos(angleRad);
        ball.velocityY = ball.speed * Math.sin(angleRad);

        // Increase ball speed slightly after each hit
        ball.speed += 0.2;
    }

    // Ball goes out of the left or right boundary
    if (ball.x - ball.radius < 0) {
        ai.score++;
        resetBall();
    } else if (ball.x + ball.radius > canvas.width) {
        player.score++;
        resetBall();
    }
}

// Render the game
function render() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw paddles, ball, net, and scores
    drawRect(player.x, player.y, player.width, player.height, player.color);
    drawRect(ai.x, ai.y, ai.width, ai.height, ai.color);
    drawBall(ball.x, ball.y, ball.radius, ball.color);
    drawNet();
    drawText(player.score, canvas.width / 4, canvas.height / 5);
    drawText(ai.score, 3 * canvas.width / 4, canvas.height / 5);
}

// Game loop
function gameLoop() {
    update();
    render();
}

// Run the game loop at 60 FPS
setInterval(gameLoop, 1000 / 60);
